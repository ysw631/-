
var express = require('express');
var bodyParser = require('body-parser');

var items = [{
    name: '1',
    price : '2000'
}, {
    name: '2',
    price: '5000'
}, {
    name : '3',
    price : '5000'
}];

var app = express();
app.use(express.static('public'));
app.use(bodyParser.urlencoded({extended: false}));

app.all('/data.html', function (request, response){
    var output = '';
    items.forEach(function(item){
        output += '<div>';
        output +=' <h1>' + item.name + '</h1>';
        output += '<h2>' + item.price + '</h2>';
        output += '</div>';

    });
    response.send(output);
});


app.get('/products', function (request, response){
    response.send(items);
});
app.get('/products/:id', function (request, response){
    var id = Number(request.params.id);

   if (isNaN(id)){

    response.send({
        error: '숫자를 입력하세요!'
    });
   }
   else if (items[id]) {

    response.send(items[id]);
   }
   else {
       response.send({
           error : '존재하지 않는 데이터입니다!'
       })
   }
});



//웹 서버를 실행합니다.
app.listen(80, function(){
    console.log('Server Running at http://127.0.0.1:80');
});